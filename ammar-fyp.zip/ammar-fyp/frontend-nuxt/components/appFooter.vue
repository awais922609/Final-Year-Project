<template>
  <div class="bg-[#2c333e] h-20 flex flex-row justify-between items-center px-[20px]">
    <div class="text-[#ffffff]">
      <!-- <script>
        document.write(new Date().getFullYear());
      </script> -->
      &copy; All rights reserved.
    </div>
    <div id="links">
      <a class="text-[#ffffff] mr-[10px]" href="javascript:void(0);">About Us</a>
      <a class="text-[#ffffff] mr-[10px]" href="javascript:void(0);">Help</a>
      <a class="text-[#ffffff] mr-[10px]" href="javascript:void(0);">Contact Us</a>
    </div>
  </div>
</template>
