
import { defuFn } from '/home/dell/Desktop/fyp/ffff/ammar-fyp/frontend-nuxt/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
