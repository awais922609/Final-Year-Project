<template>
  <div class="w-screen h-screen box-border">
    <NuxtPage />
  </div>
</template>
